<li><a href="{{route('colour_prediction',13)}}"><i class="fa fa-user orange_color"></i> <span>Andar Bahar</span></a></li>
