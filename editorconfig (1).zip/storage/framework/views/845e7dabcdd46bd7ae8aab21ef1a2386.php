 <?php if(Session::has('id')){

}else{
	
	header("Location: https://root.thargames.live/");
            die; 

} 
      
?>
<div id="content">
    <!-- topbar -->
    <div class="topbar">
       <nav class="navbar navbar-expand-lg navbar-light">
          <div class="full">
             <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
             <div class="logo_section">
                <h3 class="img-responsive text-white mt-3 ml-2" style="color:red;">𝕋𝕙𝕒𝕚𝕝𝕒𝕟𝕕 𝔾𝕒𝕞𝕖</h3>
                
             </div>
             <div class="right_topbar">
                <div class="icon_info">
                   
                   <ul class="user_profile_dd">
                      <li>
                         <a class="dropdown-toggle" data-toggle="dropdown">
                             <!--<img class="img-responsive rounded-circle" src="https://root.jupitergames.app/uploads/jupiter_logo.png" alt="#" />-->
                             <span class="name_user">Admin</span></a>
                         <div class="dropdown-menu">
                            <!--<a class="dropdown-item" href="#">My Profile</a>-->
                            
                            <a class="dropdown-item" href="<?php echo e(route('auth.logout')); ?>"><span>Log Out</span> <i class="fa fa-sign-out"></i></a>
                         </div>
                      </li>
                   </ul>
                </div>
             </div>
          </div>
       </nav>
    </div>
    <!-- end topbar -->


 <?php /**PATH /home/u921379270/domains/mobileappdemo.net/public_html/thailand/resources/views/admin/body/header.blade.php ENDPATH**/ ?>