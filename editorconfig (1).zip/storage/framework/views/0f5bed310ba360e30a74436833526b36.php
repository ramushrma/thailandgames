  <li>
     <a href="#app" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-object-group blue2_color"></i>            <span>Aviator</span></a>
     <ul class="collapse list-unstyled" id="app">
        <li><a href="<?php echo e(route('bet_history' ,5)); ?>">> <span>Bet</span></a></li>
        <li><a href="<?php echo e(route('result' , 5)); ?>">> <span>Result</span></a></li>
     </ul>
  </li><?php /**PATH /home/u921379270/domains/mobileappdemo.net/public_html/thailand/resources/views/admin/body/aviator_sidebar.blade.php ENDPATH**/ ?>