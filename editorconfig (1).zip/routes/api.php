
<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\PayingController;
use App\Http\Controllers\Api\GameApiController;
use App\Http\Controllers\Api\AviatorApiController;


// IP	145.223.17.195
// Port	65002
// Username	u921379270

Route::post('/register',[UserController::class,'register']);
Route::post('/login',[UserController::class,'login']);
Route::get('/profile/{id}', [UserController::class, 'profile']);
Route::get('/wallet/{id}', [UserController::class, 'wallet']);
Route::post('/updateprofile', [UserController::class, 'updateprofile']);
Route::get('/allimage', [UserController::class, 'allimage']);
Route::post('/editpassword', [UserController::class, 'editpassword']);
Route::get('/notification', [UserController::class, 'notification']);
Route::get('/aboutus/{type}', [UserController::class, 'about_us']);
Route::post('/giftcards', [UserController::class, 'giftcards']);
Route::get('/Gifthistory/{userid}', [UserController::class, 'Gifthistory']);
Route::post('/feedback', [UserController::class, 'feedback']);
Route::get('/wallettransfer/{userid}', [UserController::class, 'wallettransfer']);
Route::get('/bankname', [UserController::class, 'bankname']);
Route::post('/addbank', [UserController::class, 'addbank']);
Route::get('/viewbank/{userid}', [UserController::class, 'viewbank']);
Route::get('/getPaymentLimits', [UserController::class, 'getPaymentLimits']);
Route::post('/withdrawal', [UserController::class, 'withdrawal']);
Route::post('/withdrawalhistory', [UserController::class, 'withdrawalhistory']);
Route::post('/payinghistory', [UserController::class, 'payinghistory']);
Route::get('/TransactionType', [UserController::class, 'TransactionType']);
Route::post('/Transaction_wallet_histories', [UserController::class, 'walletHistories']);



Route::controller(GameApiController::class)->group(function () {
     Route::post('/bets', 'bet');
     Route::post('/dragon_bet', 'dragon_bet');
     Route::get('/win-amount', 'win_amount');
     Route::get('/results','results');
     Route::get('/ab_results','ab_results');
     Route::get('/last_five_result','lastFiveResults');
     Route::get('/last_result','lastResults');
     Route::post('/bet_history','bet_history');
     Route::get('/cron/{game_id}/','cron');
     /// mine game route //
     Route::post('/mine_bet','mine_bet');
     Route::post('/mine_cashout','mine_cashout');
     Route::get('/mine_result','mine_result');
     Route::get('/mine_multiplier','mine_multiplier');
    
    //// Plinko Game Route /////
    
     Route::post('/plinko_bet','plinkoBet');
     Route::get('/plinko_index_list','plinko_index_list');
     Route::get('/plinko_result','plinko_result');
     Route::get('/plinko_cron','plinko_cron');
     Route::post('/plinko_multiplier','plinko_multiplier'); 
});


     Route::controller(AviatorApiController::class)->group(function () {
     Route::get('/aviator_bet','aviatorBet');
     Route::post('/aviator_cashout','aviator_cashout');
     Route::post('/aviator_history','aviator_history');
     Route::get('/aviator_last_five_result','last_five_result');
     Route::get('/aviator_bet_cancel','bet_cancel');
     Route::get('/result_half_new','result_half_new');
     Route::post('/result_insert_new','result_insert_new');
});




Route::post('/paywalex', [PayingController::class, 'paywalex']); 













