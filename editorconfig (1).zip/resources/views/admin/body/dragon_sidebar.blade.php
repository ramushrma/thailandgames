<li><a href="{{route('colour_prediction',10)}}"><i class="fa fa-user orange_color"></i> <span>Dragon</span></a></li>
