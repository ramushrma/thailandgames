  <li>
     <a href="#app" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-object-group blue2_color"></i>            <span>Aviator</span></a>
     <ul class="collapse list-unstyled" id="app">
        <li><a href="{{route('bet_history' ,5)}}">> <span>Bet</span></a></li>
        <li><a href="{{route('result' , 5)}}">> <span>Result</span></a></li>
     </ul>
  </li>